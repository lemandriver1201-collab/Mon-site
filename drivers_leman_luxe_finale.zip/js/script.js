document.getElementById('menu-toggle').addEventListener('click', () => {
  const menu = document.getElementById('menu-list');
  menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
});

function setLang(lang) {
  const translations = {
    fr: { title: "Driver Leman Luxe", intro: "Idéalement situé en plein cœur de Genève...",
          reservationTitle: "Réserver un trajet", pickup: "Lieu de prise en charge :", dropoff: "Lieu de destination :",
          passengers: "Nombre de passagers :", date: "Date et heure :", book: "Réserver",
          contactTitle: "Contactez-nous", firstname: "Prénom :", lastname: "Nom :", phone: "Téléphone :",
          email: "Email :", message: "Message :", send: "Envoyer"},
    en: { title: "Driver Leman Luxe", intro: "Ideally located in the heart of Geneva...",
          reservationTitle: "Book a ride", pickup: "Pickup location:", dropoff: "Drop-off location:",
          passengers: "Number of passengers:", date: "Date & time:", book: "Book",
          contactTitle: "Contact us", firstname: "First name:", lastname: "Last name:", phone: "Phone:",
          email: "Email:", message: "Message:", send: "Send"},
    de: { title: "Driver Leman Luxe", intro: "Ideal im Herzen von Genf gelegen...",
          reservationTitle: "Fahrt buchen", pickup: "Abholort:", dropoff: "Zielort:",
          passengers: "Anzahl der Passagiere:", date: "Datum & Uhrzeit:", book: "Buchen",
          contactTitle: "Kontaktieren Sie uns", firstname: "Vorname:", lastname: "Nachname:", phone: "Telefon:",
          email: "E-Mail:", message: "Nachricht:", send: "Senden"}
  };

  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    el.textContent = translations[lang][key];
  });
}
